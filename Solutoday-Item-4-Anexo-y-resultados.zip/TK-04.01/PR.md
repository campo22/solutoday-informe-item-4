# [TK-04.01] Proxy confiable, cabeceras de seguridad y límites de tráfico por canal

- **Tarjeta Trello:** [TK-04.01 · Configurar proxy, WAF y límites de tráfico](https://trello.com/c/oIbmmf9b)
- **Épica:** [EP-04 · Firewall y observabilidad](https://trello.com/c/iAPnTdbS)
- **Rama base:** `develop` (`cd7cf7d08bffd91a9f06a3554b96fe24aafed4f7`)
- **Rama de tarea:** `feat/tk-04-01-proxy-waf-limites`

---

## 1. Problema inicial e impacto potencial para Solutoday

En la revisión de `web-v2` (`origin/develop @ cd7cf7d`):
1. `app/Providers/RouteServiceProvider.php` únicamente definía un limitador genérico `api` (`60 req/min`). Rutas públicas sensibles como `POST /api/login`, `POST /api/forgot-password`, `POST /api/contact-us`, `POST /api/check-username`, `POST /user-login`, `POST /forgot-password`, `POST /reset-password` y `POST /user-subscribe` carecían de cuotas diferenciadas por tipo de operación.
2. `app/Http/Middleware/TrustProxies.php` no contemplaba la extracción segura de `CF-Connecting-IP` detrás de Cloudflare cuando se activa detrás de un proxy confiable, y las respuestas HTTP no emitían cabeceras de endurecimiento (`X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Strict-Transport-Security`).
3. `ec2/server/config/docker-compose.yml` publicaba el puerto administrativo `81:81` de Nginx Proxy Manager en todas las interfaces (`0.0.0.0:81`).

**Impacto potencial:** Sin cuotas diferenciadas, un ataque de fuerza bruta o spam sobre login y formularios públicos puede degradar el servicio o bloquear a usuarios legítimos; sin cabeceras de seguridad y con el puerto `81` abierto en la definición del proxy se amplía la superficie de exposición del origen. *(Riesgos observados en auditoría de código; no corresponden a un incidente documentado en producción.)*

---

## 2. Solución implementada (Antes vs. Después)

```mermaid
flowchart TB
  subgraph ANTES_0401["ANTES (LÍNEA BASE EN DEVELOP @ CD7CF7D)"]
    direction LR
    A1["1. Tráfico entrante<br/>Login, formularios, API y webhooks<br/>sin cuotas diferenciadas"] --> A2["2. Rutas públicas sin throttle propio<br/>POST /api/login, forgot-password,<br/>contact-us y user-subscribe expuestos"] --> A3["3. Origen y cabeceras<br/>Puerto 81 en 0.0.0.0:81 y respuestas<br/>sin cabeceras HTTP de endurecimiento"]
  end

  subgraph DESPUES_0401["DESPUÉS (SOLUCIÓN TK-04.01)"]
    direction LR
    B1["1. Perímetro y Proxy Confiable<br/>TrustProxies valida IP real desde proxy<br/>autorizado (X-Forwarded-For / CF-Connecting-IP)"] --> B2["2. RateLimiters por Categoría<br/>• auth-login (IP + cuenta)<br/>• password-recovery<br/>• public-forms y webhooks"] --> B3["3. Cabeceras y Continuidad<br/>SecurityHeaders activos; puerto 81 en loopback;<br/>login, formularios y webhooks operan 200 OK"]
  end
```

### Flujo de una petición HTTP con `TK-04.01`

```mermaid
sequenceDiagram
  autonumber
  participant Client as Cliente / App / Pasarela
  participant Proxy as Cloudflare / Nginx Proxy
  participant TP as TrustProxies
  participant SEC as RequireHttps + SecurityHeaders
  participant RL as RateLimiter por Canal
  participant App as Controlador Laravel

  Client->>Proxy: Petición HTTPS (login, formulario o webhook)
  Proxy->>TP: Reenvía con X-Forwarded-Proto y CF-Connecting-IP
  alt Proxy está en TRANSPORT_TRUSTED_PROXIES
    TP->>SEC: Resuelve IP real del cliente y esquema HTTPS
  else Conexión directa no confiable
    TP->>SEC: Ignora cabeceras reenviadas (sin spoofing de IP)
  end
  SEC->>RL: Valida HTTPS y prepara cabeceras defensivas (HSTS/nosniff/SAMEORIGIN)
  alt Dentro de la cuota (auth-login / public-forms / webhooks)
    RL->>App: Permite el paso al controlador
    App-->>Client: 200 OK + SecurityHeaders
  else Excede el umbral configurado
    RL-->>Client: 429 Too Many Requests + Retry-After (sin afectar otras cuentas)
  end
```

### Cambios realizados por archivo
- `config/transport.php`: agrega `trust_cloudflare_headers`, `security_headers_enabled`, `hsts_max_age` y cuotas configurables `rate_limits` (`api_per_minute`, `auth_login_per_minute`, `auth_login_ip_per_minute`, `password_recovery_per_minute`, `public_forms_per_minute`, `webhooks_per_minute`).
- `app/Http/Middleware/TrustProxies.php`: cuando `trust_cloudflare_headers=true` y la petición proviene de un proxy autorizado (`isFromTrustedProxy()`), resuelve la IP real desde `CF-Connecting-IP` si es una IP válida; rechaza cualquier intento de spoofing desde IPs no confiables.
- `app/Http/Middleware/SecurityHeaders.php` y `app/Http/Kernel.php`: nuevo middleware global que aplica `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy: strict-origin-when-cross-origin` y `Strict-Transport-Security` únicamente bajo HTTPS.
- `app/Providers/RouteServiceProvider.php`: define los limitadores nombrados `auth-login` (doble clave por `IP + cuenta` y tope general por `IP` para no bloquear otros usuarios detrás del mismo NAT), `password-recovery`, `public-forms` y `webhooks`.
- `routes/api.php`, `routes/auth.php`, `routes/frontend.php`: asigna los limitadores a login, recuperación de clave y formularios públicos.
- `ec2/server/config/docker-compose.yml`: restringe el puerto administrativo de Nginx Proxy Manager a `127.0.0.1:81:81`.
- `.env.example`: documenta las variables de configuración con valores seguros por defecto.
- `tests/Feature/Tk0401ProxyAndRateLimitTest.php`: suite automatizada de 7 pruebas de proxy, cabeceras y rate-limiting.

---

## 3. Evidencia de verificación (Laboratorio local aislado)

- **Ambiente:** Contenedor Docker PHP 8.4.27 + PHPUnit 11.5.58 + MySQL 8.4.13 desechable.
- **Sintaxis PHP (`php -l`):** 9 archivos verificados, 0 errores.
- **Suite dirigida (`Tk0401ProxyAndRateLimitTest` + `Bg0205TransportTest`):** **14 pruebas, 81 aserciones, 0 fallos, 0 errores**.
- **Regresión integrada (combinada con `TK-04.02` en MySQL 8.4.13 desechable):** **136 pruebas y 785 aserciones (0 fallos, 0 errores, 0 omisiones)** — 128 pruebas / 734 aserciones en la suite general (`solutoday_bg0203_item04`) + 8 pruebas / 51 aserciones en la suite financiera (`solutoday_bg0204_item04`).

## 4. Pendientes externos (`TK-01.01`)
- La aplicación directa de reglas en la consola de Cloudflare y el grupo de seguridad AWS EC2 de Solutoday queda documentada en `docs/entregas/ITEM-04/TK-04.01/CLOUDFLARE-WAF-PLANTILLA.md` y pendiente de que Solutoday entregue los accesos solicitados en `TK-01.01`.
