# [TK-04.02] Observabilidad de fallos (API, cola, integraciones y pagos), redacción de datos y alertas técnicas

- **Tarjeta Trello:** [TK-04.02 · Observar fallos y recibir alertas técnicas](https://trello.com/c/1d5tAxji)
- **Épica:** [EP-04 · Firewall y observabilidad](https://trello.com/c/iAPnTdbS)
- **Rama base:** `develop` (`cd7cf7d08bffd91a9f06a3554b96fe24aafed4f7`)
- **Rama de tarea:** `feat/tk-04-02-observabilidad-alertas`

---

## 1. Problema inicial e impacto potencial para Solutoday

En la revisión de `web-v2` (`origin/develop @ cd7cf7d`):
1. `app/Exceptions/Handler.php` tenía el bloque `$this->reportable(...)` vacío.
2. `supervisord.conf` ejecutaba el worker de colas (`queue:work database`), pero no existía un listener `Queue::failing(...)` que capturara ni alertara cuando un trabajo fallaba definitivamente.
3. Los fallos de integraciones externas (OpenAI, Firebase) y excepciones técnicas de pagos quedaban sin correlación común, sin canal dedicado ni aviso automático al responsable técnico, y no existía un redactor central que impidiera filtrar secretos o datos personales en logs y alertas.

**Impacto potencial:** Fallos críticos en producción (errores `5xx`, trabajos de cola caídos, errores de pagos o proveedores) podían pasar desapercibidos hasta ser reportados por clientes, o bien exponer tokens y datos personales al intentar diagnosticarlos. *(Riesgos observados en auditoría de código; no corresponden a un incidente documentado en producción.)*

---

## 2. Solución implementada (Antes vs. Después)

```mermaid
flowchart TB
  subgraph ANTES_0402["ANTES (LÍNEA BASE EN DEVELOP @ CD7CF7D)"]
    direction LR
    C1["1. Ocurre un fallo técnico<br/>Error 5xx en API, job fallido en cola,<br/>error de integración o fallo de pago"] --> C2["2. Handler reportable vacío<br/>Sin captura estructurada ni listener<br/>Queue::failing para trabajos de cola"] --> C3["3. Sin alerta ni redactor central<br/>El responsable no recibe aviso y falta<br/>filtro central contra secretos/PII"]
  end

  subgraph DESPUES_0402["DESPUÉS (SOLUCIÓN TK-04.02)"]
    direction LR
    D1["1. Captura en 4 Fuentes<br/>• API 5xx (Handler)<br/>• Cola (Queue::failing)<br/>• Integraciones (Firebase/IA)<br/>• Pagos (FinancialOperations)"] --> D2["2. ObservabilitySanitizer<br/>Redacta tokens, passwords, claves API<br/>y enmascara correos/teléfonos"] --> D3["3. Canal Observability + Alerta<br/>Registra JSON con correlation_id y envía<br/>alerta con cooldown a Mail/Webhook"]
  end
```

### Flujo de captura, redacción y alerta técnica con deduplicación (`TK-04.02`)

```mermaid
sequenceDiagram
  autonumber
  participant Src as Fuente de Fallo (API 5xx / Cola / Integración / Pago)
  participant Svc as TechnicalAlertService
  participant San as ObservabilitySanitizer
  participant Log as Canal Log (observability.log)
  participant Cache as Cache (Cooldown Fingerprint)
  participant Notif as Responsable (Mail / Webhook)

  Src->>Svc: report(category, operation, error, context)
  Svc->>San: sanitizeString() + sanitizeArray()
  San-->>Svc: Contexto limpio ([REDACTED] en secretos, PII enmascarado)
  Svc->>Cache: Cache::add("observability:cooldown:" + fingerprint, true, ttl)
  alt Primera ocurrencia en la ventana de cooldown
    Cache-->>Svc: true (despacho habilitado)
    Svc->>Notif: Envía TechnicalErrorAlertNotification (Mail y/o Webhook)
  else Ocurrencia repetida dentro del cooldown
    Cache-->>Svc: false (suprimido para evitar tormenta de alertas)
  end
  Svc->>Log: Escribe evento estructurado con correlation_id y resultado del despacho
```

### Cambios realizados por archivo
- `config/observability.php` y `config/logging.php`: definen el canal estructurado `observability` (`storage/logs/observability.log`), destinatarios configurables (`OBSERVABILITY_ALERT_EMAIL`, `OBSERVABILITY_ALERT_WEBHOOK_URL`), ventana de deduplicación (`OBSERVABILITY_ALERT_COOLDOWN_SECONDS=300`) y lista de claves sensibles.
- `app/Services/Observability/ObservabilitySanitizer.php`: redacta recursivamente claves sensibles (`password`, `token`, `secret`, `authorization`, `cookie`, `chat_gpt_key`, `firebase_id_token`, `api_key`, etc.), limpia patrones `Bearer ...`, JWTs y llaves `sk_*` en textos, y enmascara correos (`u***@dominio`) y teléfonos (`***67`).
- `app/Services/Observability/TechnicalAlertService.php` y `app/Notifications/TechnicalErrorAlertNotification.php`: registran cada fallo saneado con `correlation_id` y `fingerprint`, aplican `cooldown` en caché para evitar tormentas de correos y despachan la alerta por correo y/o webhook HTTP.
- `app/Exceptions/Handler.php`: conecta `$this->reportable(...)` para capturar excepciones técnicas `5xx` (ignorando `401`/`403`/`422`/`4xx` ordinarios; sin colisión con `$dontFlash` de `HU-03.01`).
- `app/Providers/AppServiceProvider.php`: registra `Queue::failing(...)` para reportar trabajos de cola fallidos bajo la categoría `queue`.
- `app/Http/Controllers/API/GenerateAiTextController.php`, `app/Http/Controllers/API/ChatNotificationController.php` y `app/Services/FinancialOperations.php`: reportan fallos técnicos en categorías `integration` y `payment` sin alterar las respuestas HTTP ni las transacciones existentes.
- `app/Console/Commands/SendTestTechnicalAlert.php`: comando `php artisan observability:test-alert` para verificar en laboratorio, QA o producción la emisión, redacción y recepción de alertas técnicas.
- `tests/Unit/ObservabilitySanitizerTest.php` y `tests/Feature/Tk0402ObservabilityAlertTest.php`: suites unitaria y de integración cubriendo las 4 fuentes de fallo, redacción de secretos/PII, alerta técnica y deduplicación por cooldown.

---

## 3. Evidencia de verificación (Laboratorio local aislado)

- **Ambiente:** Contenedor Docker PHP 8.4.27 + PHPUnit 11.5.58 + MySQL 8.4.13 desechable.
- **Sintaxis PHP (`php -l`):** 13 archivos verificados, 0 errores.
- **Suites de observabilidad (`ObservabilitySanitizerTest` + `Tk0402ObservabilityAlertTest`):** **6 pruebas, 34 aserciones, 0 fallos, 0 errores**.
- **Regresión integrada (combinada con `TK-04.01` en MySQL 8.4.13 desechable):** **136 pruebas y 785 aserciones (0 fallos, 0 errores, 0 omisiones)** — 128 pruebas / 734 aserciones en la suite general (`solutoday_bg0203_item04`) + 8 pruebas / 51 aserciones en la suite financiera (`solutoday_bg0204_item04`).
- **Demostración CLI (`php artisan observability:test-alert --category=payment`):** Confirmó registro estructurado con `correlation_id`, redacción `Bearer [REDACTED]`, `[REDACTED]` en `password`, `firebase_id_token` y `chat_gpt_key`, y enmascaramiento de correo (`p***@example.test`) y teléfono (`***67`).

## 4. Pendientes operativos
- Configurar en el ambiente QA / producción real `OBSERVABILITY_ALERT_EMAIL` y/o `OBSERVABILITY_ALERT_WEBHOOK_URL` del responsable de operación y repetir `php artisan observability:test-alert` en dicho ambiente.
