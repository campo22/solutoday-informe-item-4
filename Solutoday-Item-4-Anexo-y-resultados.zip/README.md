# Ítem 4 (EP-04) · Entrega Consolidada: Firewall, Proxy, Límites de Tráfico y Observabilidad

> **Fecha de cierre técnico:** 23 de noviembre de 2026 (hora de Bogotá)  
> **Estado:** **Desarrollo e integración en `develop` completados** (`web-v2 @ 974eb0269f32e1fb4318fe56e9665aad81ecd8b9`, árbol `f9913444d7350112c5db70785afe10b27d8c2f5c`) · Pendiente de aceptación empresarial y activación externa en Cloudflare/AWS (`TK-01.01`)  
> **Épica en Trello:** [EP-04 · Firewall y observabilidad](https://trello.com/c/iAPnTdbS)  
> **Tarjetas cubiertas:** [TK-04.01 · Configurar proxy, WAF y límites de tráfico](https://trello.com/c/oIbmmf9b) ([PR #11](https://github.com/Solutoday/web-v2/pull/11) fusionado en `5e3280b`) · [TK-04.02 · Observar fallos y recibir alertas técnicas](https://trello.com/c/1d5tAxji) ([PR #12](https://github.com/Solutoday/web-v2/pull/12) fusionado en `974eb02`)  
> **Informe empresarial:** [Informe ejecutivo HTML](../../portal/item-04-informe-empresarial.html) · [PDF](informe-empresarial/Solutoday-Item-4-Informe-empresarial.pdf) · [DOCX editable](informe-empresarial/Solutoday-Item-4-Informe-empresarial.docx) · [Anexo y resultados ZIP](informe-empresarial/Solutoday-Item-4-Anexo-y-resultados.zip)  
> **Visor interactivo Archify:** [`diagramas/item-04-firewall-observabilidad.html`](./diagramas/item-04-firewall-observabilidad.html)

---

## 0. Resumen de Cierre Técnico e Integración en `develop` (23 de noviembre de 2026)

| Corte | Tarjeta Trello | PR hacia `develop` | Commit de fusión en `develop` | Archivos | Validación principal |
| :--- | :--- | :--- | :--- | :---: | :--- |
| **Corte 1** | [TK-04.01](https://trello.com/c/oIbmmf9b) | [Solutoday/web-v2#11](https://github.com/Solutoday/web-v2/pull/11) | `5e3280b2297849257e7819181636b06b1ba51675` | 11 | Suite dirigida: 14 pruebas / 81 aserciones + [trazas HTTP en vivo](evidencia-integracion/trazas-http-tk0401.txt) (`403` HTTP plano, 4 cabeceras + HSTS, `200`→`429`, aislamiento `CF-Connecting-IP`, puerto `81` local) + [plantilla Cloudflare WAF](TK-04.01/CLOUDFLARE-WAF-PLANTILLA.md). |
| **Corte 2** | [TK-04.02](https://trello.com/c/1d5tAxji) | [Solutoday/web-v2#12](https://github.com/Solutoday/web-v2/pull/12) | `974eb0269f32e1fb4318fe56e9665aad81ecd8b9` | 14 | Suite dirigida: 6 pruebas / 34 aserciones + [prueba en vivo SMTP + Webhook + Cooldown](evidencia-integracion/alerta-en-vivo-smtp-webhook.txt) (2 correos SMTP y 2 webhooks recibidos, secretos `[REDACTED]`, PII enmascarada, supresión del duplicado por `cooldown`). |
| **Regresión integrada final** | [EP-04](https://trello.com/c/iAPnTdbS) | `origin/develop @ 974eb02` (árbol `f9913444`) | Incluye Ítem 2 + Ítem 3 (MFA, sesiones, recuperación) + Ítem 4 | 25 | **168 pruebas y 1,244 aserciones (0 fallos, 0 errores, 0 omisiones)** en PHP 8.4.27 / PHPUnit 11.5.58 / MySQL 8.4.13 aislado: [general (160/1,193)](evidencia-integracion/regresion-general.junit.xml) y [financiera (8/51)](evidencia-integracion/regresion-finanzas.junit.xml). |

> **Bloqueo externo registrado (fuera del repositorio):** la verificación y aplicación directa de reglas en la consola de **Cloudflare** y el despliegue de `docker-compose.yml` en **AWS EC2** siguen pendientes de entrega de accesos por parte de Solutoday ([TK-01.01](https://trello.com/c/uC10IK1Y), responsable: Yoider / Solutoday). La plantilla declarativa de WAF y las variables de entorno quedan listas para aplicación inmediata.

---

## 1. Base de revisión e independencia respecto al Ítem 3

| Repositorio | Rama base | Commit verificado | Rol en el Ítem 4 |
| :--- | :--- | :--- | :--- |
| [`web-v2`](../../../web-v2) | `origin/develop` | `cd7cf7d08bffd91a9f06a3554b96fe24aafed4f7` | **Repositorio único intervenido** (proxy, cabeceras, límites de tráfico, observabilidad, redacción de secretos/PII y alertas técnicas). |
| [`clientes-v2`](../../../clientes-v2) | `origin/develop` | `c747815845aa68cb8fb1fd3c415d53d273e9834b` | Consumidor verificado (no requiere cambios funcionales; sus solicitudes legítimas continúan operando bajo los nuevos límites). |
| [`proveedor-v2`](../../../proveedor-v2) | `origin/develop` | `c2ce02c2e0fc4257acc5c7d34eda38a1dd2c480a` | Consumidor verificado (no requiere cambios funcionales). |

### Compatibilidad en paralelo con el Ítem 3 (`HU-03.01` / `HU-03.02`)
Se cotejaron los manifiestos de [`HU-03.01` (PR #9)](../ITEM-03/HU-03.01/evidencia/manifiesto.tsv) y [`HU-03.02`](../ITEM-03/HU-03.02/evidencia/manifiesto.tsv):
* En `app/Exceptions/Handler.php`, `HU-03.01` únicamente añade `mfa_code` y `mfa_invitation` al arreglo `$dontFlash`, dejando intacto el método `register()` (`$this->reportable(...)`).
* En `app/Http/Kernel.php`, `HU-03.01` y `HU-03.02` operan sobre `$middlewareGroups['web']` y `$middlewareGroups['api']`, mientras que el endurecimiento de proxy/cabeceras del Ítem 4 opera en el arreglo global `$middleware` y en `TrustProxies` / `RouteServiceProvider`.
* Por tanto, el Ítem 4 puede desarrollarse y probarse en su propio worktree aislado desde `origin/develop @ cd7cf7d` sin bloqueo ni colisión con el Ítem 3.

```mermaid
flowchart LR
  BASE["web-v2 · origin/develop<br/>Commit base: cd7cf7d (Ítem 2 integrado)"]

  subgraph ITEM3["Ítem 3 (EP-03 · En paralelo)"]
    I3A["HU-03.01 · MFA Administrativo<br/>(PR #9 · Controladores Auth/MFA)"]
    I3B["HU-03.02 / 03.03 · Sesiones y Recuperación<br/>(Tokens Sanctum y códigos de respaldo)"]
  end

  subgraph ITEM4["Ítem 4 (EP-04 · Worktree independiente)"]
    I4A["Corte 1 · TK-04.01<br/>Proxy, Cloudflare WAF, protección de origen,<br/>cabeceras HTTP y límites de tráfico"]
    I4B["Corte 2 · TK-04.02<br/>Observabilidad (API, cola, integraciones, pagos),<br/>redactor de secretos/PII y alertas técnicas"]
  end

  BASE --> ITEM3
  BASE --> ITEM4
  I4A --> I4B
```

---

## 2. Diagnóstico estático sobre `origin/develop` (`cd7cf7d`)

| Tarea / Criterio | Estado observado en `web-v2` (`cd7cf7d`) | Brecha / Riesgo a resolver en el Ítem 4 |
| :--- | :--- | :--- |
| **TK-04.01 · Proxy, origen y TLS** | [`TrustProxies.php`](../../../web-v2/app/Http/Middleware/TrustProxies.php) valida `config('transport.trusted_proxies')` para `X-Forwarded-For` y `X-Forwarded-Proto`. [`RequireHttps.php`](../../../web-v2/app/Http/Middleware/RequireHttps.php) exige HTTPS cuando `TRANSPORT_REQUIRE_HTTPS=true`. En [`ec2/server/config/docker-compose.yml`](../../../web-v2/ec2/server/config/docker-compose.yml), Nginx Proxy Manager publica `81:81` en todas las interfaces (`0.0.0.0:81`). | 1) Soportar extracción segura de IP de cliente cuando el proxy confiable es Cloudflare (`CF-Connecting-IP`) sin permitir falsificación desde IPs no confiables.<br/>2) Emitir cabeceras HTTP de seguridad (`X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy`, `Strict-Transport-Security` bajo HTTPS).<br/>3) Restringir en el Compose de referencia el puerto administrativo `81` a interfaz local (`127.0.0.1:81:81`) y entregar la plantilla declarativa de reglas WAF de Cloudflare. |
| **TK-04.01 · Límites de tráfico compatibles con login, formularios y webhooks** | [`RouteServiceProvider.php`](../../../web-v2/app/Providers/RouteServiceProvider.php) solo define `RateLimiter::for('api')` (`60 req/min`). En [`routes/api.php`](../../../web-v2/routes/api.php), [`routes/auth.php`](../../../web-v2/routes/auth.php) y [`routes/frontend.php`](../../../web-v2/routes/frontend.php), rutas como `POST /api/login`, `POST /api/forgot-password`, `POST /api/contact-us`, `POST /api/check-username`, `POST /user-login` y `POST /user-subscribe` carecen de perfiles `RateLimiter` dedicados. | Definir perfiles `RateLimiter` configurables en `RouteServiceProvider` y `config/transport.php` para:<br/>• `auth-login` (IP + cuenta normalizada, evitando bloquear otros usuarios en el mismo NAT).<br/>• `password-recovery` (recuperación y reseteo de clave).<br/>• `public-forms` (`contact-us`, `check-username`, `user-subscribe`).<br/>• `webhooks` (cuota amplia por IP/origen para no rechazar confirmaciones legítimas de pasarelas). |
| **TK-04.02 · Visibilidad de fallos de API, cola, integraciones y pagos** | [`Handler.php`](../../../web-v2/app/Exceptions/Handler.php) tiene `$this->reportable(...)` vacío. [`supervisord.conf`](../../../web-v2/supervisord.conf) ejecuta `queue:work database`, pero no hay listener `Queue::failing(...)`. Los fallos de integraciones (Firebase/IA) y pagos quedan dispersos en `laravel.log` sin esquema común ni correlación. | Centralizar la captura de eventos técnicos en `TechnicalAlertService` con canal dedicado `observability` en `config/logging.php`, cubriendo:<br/>1) Excepciones no controladas HTTP `5xx` (`Handler::reportable`).<br/>2) Trabajos fallidos de cola (`Queue::failing`).<br/>3) Fallos de integraciones externas (Firebase/IA/correo).<br/>4) Fallos en operaciones financieras (`FinancialOperationService`). |
| **TK-04.02 · Alerta técnica y redacción de secretos/PII** | `config/logging.php` no aplica un procesador de redacción de secretos/PII ni existe un mecanismo de despacho de alertas técnicas con control anti-tormenta (deduplicación). | 1) Crear `ObservabilitySanitizer` para redactar recursivamente credenciales (`password`, `token`, `secret`, `authorization`, `cookie`, `chat_gpt_key`, `firebase_id_token`, `api_key`, Bearer tokens) y enmascarar correos y teléfonos.<br/>2) Despachar alertas técnicas (por correo `Mail` y/o webhook HTTP configurable) con ventana de deduplicación (`cooldown`) en caché.<br/>3) Incluir comando `php artisan observability:test-alert` para demostrar extremo a extremo la emisión y recepción de la alerta técnica. |

---

## 3. Diagramas de Arquitectura del Plan (Antes vs. Después)

### 3.1 Corte 1 (`TK-04.01`): Proxy, WAF, Protección de Origen y Límites de Tráfico

```mermaid
flowchart TB
  subgraph ANTES_0401["ANTES (LÍNEA BASE EN DEVELOP @ CD7CF7D)"]
    direction LR
    A1["1. Tráfico entrante<br/>Login, formularios, API y webhooks<br/>caen en el mismo límite general"] --> A2["2. Rutas públicas expuestas<br/>POST /api/login, forgot-password,<br/>contact-us y user-subscribe sin cuota"] --> A3["3. Origen y cabeceras<br/>Puerto 81 abierto en compose y respuestas<br/>sin cabeceras HTTP de endurecimiento"]
  end

  subgraph DESPUES_0401["DESPUÉS (SOLUCIÓN PROPUESTA TK-04.01)"]
    direction LR
    B1["1. Perímetro y Proxy Confiable<br/>Cloudflare WAF + TrustProxies valida IP<br/>real (X-Forwarded-For / CF-Connecting-IP)"] --> B2["2. RateLimiters por Categoría<br/>• auth-login (IP + cuenta)<br/>• password-recovery<br/>• public-forms<br/>• webhooks (alta disponibilidad)"] --> B3["3. Cabeceras y Continuidad<br/>SecurityHeaders activos; login, formularios<br/>y webhooks legítimos responden 200 OK"]
  end
```

### 3.2 Corte 2 (`TK-04.02`): Observabilidad de Fallos, Redacción de Datos y Alertas Técnicas

```mermaid
flowchart TB
  subgraph ANTES_0402["ANTES (LÍNEA BASE EN DEVELOP @ CD7CF7D)"]
    direction LR
    C1["1. Ocurre un fallo técnico<br/>Excepción 5xx en API, job fallido en cola,<br/>error de integración o fallo de pago"] --> C2["2. Handler reportable vacío<br/>Sin captura estructurada ni listener<br/>Queue::failing para trabajos de cola"] --> C3["3. Sin alerta ni redactor central<br/>El responsable no recibe alerta y no hay<br/>filtro central contra secretos/PII"]
  end

  subgraph DESPUES_0402["DESPUÉS (SOLUCIÓN PROPUESTA TK-04.02)"]
    direction LR
    D1["1. Captura en 4 Fuentes<br/>• API 5xx (Handler)<br/>• Cola (Queue::failing)<br/>• Integraciones (Firebase/IA)<br/>• Pagos (FinancialOperation)"] --> D2["2. ObservabilitySanitizer<br/>Redacta tokens, passwords, claves API<br/>y enmascara correos/teléfonos"] --> D3["3. Canal Observability + Alerta<br/>Registra JSON estructurado y envía alerta<br/>con deduplicación (cooldown) a Mail/Webhook"]
  end
```

---

## 4. Detalle de Archivos a Crear o Modificar en `web-v2`

### Corte 1 · `TK-04.01` (Rama propuesta: `feat/tk-04-01-proxy-waf-limites`)

| Archivo en `web-v2` | Acción | Cambio detallado |
| :--- | :--- | :--- |
| `config/transport.php` | Modificar | Añadir banderas y umbrales configurables por entorno: `trust_cloudflare_headers` (`TRANSPORT_TRUST_CLOUDFLARE_HEADERS`), `security_headers_enabled` (`TRANSPORT_SECURITY_HEADERS_ENABLED`), y cuotas por minuto para `rate_limits` (`api`, `auth_login`, `password_recovery`, `public_forms`, `webhooks`). |
| `app/Http/Middleware/TrustProxies.php` | Modificar | Mantener la validación CIDR de `trusted_proxies` y, cuando `trust_cloudflare_headers` esté activo y la petición provenga de un proxy confiable, resolver de forma segura la IP real del cliente desde `CF-Connecting-IP` (ignorando la cabecera si la conexión no viene de un proxy autorizado). |
| `app/Http/Middleware/SecurityHeaders.php` | **Nuevo** | Añadir cabeceras defensivas compatibles con el panel Blade/Vue y la API JSON: `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy: strict-origin-when-cross-origin`, y `Strict-Transport-Security: max-age=31536000; includeSubDomains` cuando la solicitud sea HTTPS. |
| `app/Http/Kernel.php` | Modificar | Registrar `\App\Http\Middleware\SecurityHeaders::class` en el stack global `$middleware`. |
| `app/Providers/RouteServiceProvider.php` | Modificar | Registrar los limitadores nombrados `auth-login` (clave compuesta por IP + email/username normalizado + fallback por IP), `password-recovery`, `public-forms` y `webhooks`, con respuestas `429` coherentes en JSON o web. |
| `routes/api.php` | Modificar | Aplicar `throttle:auth-login` a `POST /api/login`, `throttle:password-recovery` a `POST /api/forgot-password`, y `throttle:public-forms` a `POST /api/contact-us` y `POST /api/check-username`. |
| `routes/auth.php` y `routes/frontend.php` | Modificar | Aplicar `throttle:auth-login` a `POST /user-login`, `throttle:password-recovery` a `POST /forgot-password` y `POST /reset-password`, y `throttle:public-forms` a `POST /user-subscribe`. |
| `ec2/server/config/docker-compose.yml` | Modificar | Cambiar la publicación del puerto administrativo de Nginx Proxy Manager de `'81:81'` a `'127.0.0.1:81:81'` para evitar exposición pública directa del panel del proxy. |
| `.env.example` | Modificar | Documentar las variables de configuración de proxy, cabeceras y límites de tráfico con valores seguros por defecto. |
| `tests/Feature/Tk0401ProxyAndRateLimitTest.php` | **Nuevo** | Suite automatizada que verifica proxy confiable vs. intento de spoofing de IP, cabeceras de seguridad, bloqueo `429` al exceder umbrales y operación normal (`200`) de login, formularios y webhooks legítimos. |

### Corte 2 · `TK-04.02` (Rama propuesta: `feat/tk-04-02-observabilidad-alertas`)

| Archivo en `web-v2` | Acción | Cambio detallado |
| :--- | :--- | :--- |
| `config/observability.php` | **Nuevo** | Configuración de observabilidad y alertas técnicas: `enabled`, canales de notificación (`mail_to`, `webhook_url`), ventana de deduplicación (`cooldown_seconds`, por defecto `300`), categorías observadas (`api`, `queue`, `integration`, `payment`) y lista de claves sensibles a redactar. |
| `config/logging.php` | Modificar | Añadir canal `observability` (`storage/logs/observability.log`, formato estructurado) para separar los eventos críticos auditables del ruido general de depuración. |
| `app/Services/Observability/ObservabilitySanitizer.php` | **Nuevo** | Servicio puro y determinista que limpia arreglos, textos, URLs y contextos de excepción: reemplaza secretos (`password`, `token`, `secret`, `authorization`, `chat_gpt_key`, `firebase_id_token`, `api_key`, `client_secret`, JWTs y `Bearer ...`) por `[REDACTED]` y enmascara correos (`u***@dominio.com`) y teléfonos (`***1234`). |
| `app/Services/Observability/TechnicalAlertService.php` | **Nuevo** | Punto central para registrar un fallo técnico (`recordFailure(string $category, string $operation, Throwable|string $error, array $context = [])`), asignar un `correlation_id`, escribir en el canal `observability` tras pasar por `ObservabilitySanitizer`, y despachar alerta técnica respetando la ventana de deduplicación (`cooldown`) en caché. |
| `app/Notifications/TechnicalErrorAlertNotification.php` | **Nuevo** | Notificación de alerta técnica (canal `mail` y/o payload JSON para webhook) que incluye categoría, operación, ambiente, `correlation_id`, marca de tiempo y resumen saneado sin credenciales ni PII. |
| `app/Exceptions/Handler.php` | Modificar | En `$this->reportable(...)`, reportar excepciones no controladas a `TechnicalAlertService` bajo la categoría `api` (excluyendo errores de validación `422` o autenticación `401`/`403` ordinarios). |
| `app/Providers/AppServiceProvider.php` | Modificar | Registrar `Queue::failing(...)` para que todo trabajo de cola que falle notifique automáticamente a `TechnicalAlertService` bajo la categoría `queue`. |
| `app/Services/FinancialOperationService.php` y servicios de integración (`GenerateAiTextController`, `ChatNotificationController`) | Modificar | Reportar a `TechnicalAlertService` cuando ocurra una excepción técnica en una operación financiera (`payment`) o en el llamado a un proveedor externo (`integration`), conservando el comportamiento actual hacia el cliente. |
| `app/Console/Commands/SendTestTechnicalAlert.php` | **Nuevo** | Comando `php artisan observability:test-alert` para demostrar en laboratorio, QA o producción la emisión, redacción y recepción de una alerta técnica en la bandeja o webhook configurado. |
| `tests/Unit/ObservabilitySanitizerTest.php` y `tests/Feature/Tk0402ObservabilityAlertTest.php` | **Nuevos** | Pruebas unitarias y de integración que verifican las 4 categorías (`api`, `queue`, `integration`, `payment`), la recepción de la alerta técnica, la deduplicación por `cooldown` y la ausencia total de secretos y datos personales. |

---

## 5. Matriz de Validación y Evidencia por Criterio de Aceptación

| Tarjeta y Criterio | Comportamiento que protege | Tipo de prueba | Evidencia que se entregará |
| :--- | :--- | :--- | :--- |
| **TK-04.01 · Criterio 1:** Identificar plan contratado, dominios y reglas WAF y de límites aplicadas | Documentar reglas de borde (Cloudflare WAF) y aplicar límites de tráfico por tipo de ruta en `web-v2`. | Prueba automatizada (`Tk0401ProxyAndRateLimitTest`) + matriz documental de reglas WAF | JUnit XML + documento de reglas Cloudflare WAF y estado de acceso externo (`TK-01.01`). |
| **TK-04.01 · Criterio 2:** Verificar protección del origen y TLS, con pruebas autorizadas y acotadas | Impedir spoofing de IP desde clientes directos, exigir HTTPS cuando está activo, aplicar `SecurityHeaders` y cerrar puerto `81` público en Compose. | Prueba automatizada + recorrido HTTP local con proxy simulado | JUnit XML + trazas HTTP comprobando `403` en HTTP, cabeceras `X-Content-Type-Options`/`X-Frame-Options`/`HSTS` y rechazo de `CF-Connecting-IP` no confiable. |
| **TK-04.01 · Criterio 3:** Verificar que login, webhooks y formularios legítimos continúan operando | Garantizar que usuarios reales y pasarelas no sufran bloqueos por falsos positivos y que el rate-limit de un atacante no tumbe a otros usuarios. | Prueba automatizada + recorrido HTTP sobre MySQL 8.4 aislado | JUnit XML + pruebas de `POST /api/login`, `POST /api/contact-us`, `POST /api/check-username` y ruta de webhook respondiendo `200 OK` dentro del umbral y `429` al superarlo. |
| **TK-04.02 · Criterio 1:** Configurar fuentes de métricas/registros y visibilidad de fallos (API, cola, integraciones y pagos) | Dar visibilidad inmediata con `correlation_id` y categoría cuando falla un endpoint `5xx`, un job de cola, una integración externa o un pago. | Prueba automatizada (`Tk0402ObservabilityAlertTest`) | JUnit XML + extracto del registro estructurado `observability.log` con los 4 tipos de fallo simulados. |
| **TK-04.02 · Criterio 2:** Demostrar una alerta de error técnico y su recepción por el responsable | Asegurar que el responsable técnico reciba el aviso del fallo sin tormenta de correos duplicados. | Prueba automatizada (`Notification::fake()` / `Http::fake()`) + prueba real con `observability:test-alert` en Mailpit/log | JUnit XML + captura/salida de la alerta recibida por el destinatario configurado y prueba de `cooldown`. |
| **TK-04.02 · Criterio 3:** Verificar que los datos visibles no contienen credenciales ni datos personales innecesarios | Evitar que un log o correo de alerta filtre `chat_gpt_key`, `firebase_id_token`, contraseñas, tokens Bearer, correos completos o teléfonos. | Prueba unitaria (`ObservabilitySanitizerTest`) y de integración | JUnit XML demostrando que payloads con credenciales y PII quedan redactados como `[REDACTED]` y enmascarados tanto en disco como en la alerta enviada. |

---

## 6. Dependencias Externas y Decisiones Registradas

1. **Consola de Cloudflare y servidor AWS de Solutoday (`TK-01.01`):**
   * Tal como consta en [`07-inventario-infraestructura-servicios.md`](../../07-inventario-infraestructura-servicios.md#L37) y en la tarjeta [`TK-01.01`](https://trello.com/c/uC10IK1Y), Solutoday aún no ha entregado acceso a la consola de Cloudflare ni a la cuenta AWS EC2.
   * **Acción en este ítem:** Implementamos y validamos al 100% los controles en `web-v2` y en la configuración Docker del repositorio, dejamos lista la guía declarativa de reglas Cloudflare WAF para aplicar apenas Yoider reciba el acceso, y registramos en Trello el punto externo como **Bloqueado por acceso externo (`TK-01.01`, responsable: Yoider / Solutoday)** sin detener la entrega de código.
2. **Aprobación requerida para iniciar:**
   * Conforme a [`AGENTS.md`](../../../AGENTS.md), **no se ha editado ningún archivo funcional en `web-v2`**. Una vez apruebes este plan, crearemos el worktree aislado desde `origin/develop @ cd7cf7d`, implementaremos los cambios, ejecutaremos las suites en MySQL aislado y te presentaremos los diffs por archivo.
